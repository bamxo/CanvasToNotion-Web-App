const admin = require('firebase-admin');

// Initialize Firebase Admin only once
let firebaseInitialized = false;
function initializeFirebase() {
  if (firebaseInitialized) return;

  try {
    // Initialize directly with environment variables instead of service account json
    admin.initializeApp({
      credential: admin.credential.cert({
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL || `firebase-adminsdk-fbsvc@${process.env.FIREBASE_PROJECT_ID}.iam.gserviceaccount.com`,
        // Try a few different ways to handle the private key
        privateKey: (
          process.env.FIREBASE_PRIVATE_KEY || 
          process.env.FIREBASE_PRIVATE_KEY_BASE64 && Buffer.from(process.env.FIREBASE_PRIVATE_KEY_BASE64, 'base64').toString('utf8') || 
          ''
        ).replace(/\\n/g, '\n')
      }),
      databaseURL: process.env.FIREBASE_DATABASE_URL
    });
    
    console.log('Firebase Admin SDK initialized successfully');
    firebaseInitialized = true;
  } catch (error) {
    console.error('Error initializing Firebase Admin SDK:', error);
    throw error;
  }
}

exports.handler = async function(event, context) {
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Content-Type': 'application/json'
  };
  
  // Handle OPTIONS requests (CORS preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }
  
  // Parse the path to determine what to do
  const path = event.path.replace('/.netlify/functions/firebase-simpleapi', '');
  
  try {
    // Handle different routes
    if (path === '/health' || path === '') {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          status: 'ok',
          timestamp: new Date().toISOString()
        })
      };
    }
    
    // Initialize Firebase for the endpoints that need it
    if (path.startsWith('/firebase-test')) {
      try {
        // Initialize Firebase
        initializeFirebase();
        
        // Return success message
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            message: 'Firebase initialized successfully',
            databaseURL: process.env.FIREBASE_DATABASE_URL,
            projectId: process.env.FIREBASE_PROJECT_ID
          })
        };
      } catch (firebaseError) {
        // Return detailed error info for troubleshooting
        return {
          statusCode: 500,
          headers,
          body: JSON.stringify({
            error: 'Firebase initialization error',
            message: firebaseError.message,
            stack: firebaseError.stack,
            projectId: process.env.FIREBASE_PROJECT_ID,
            databaseURL: process.env.FIREBASE_DATABASE_URL,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL || `firebase-adminsdk-fbsvc@${process.env.FIREBASE_PROJECT_ID}.iam.gserviceaccount.com`,
          })
        };
      }
    }
    
    // Default 404 response
    return {
      statusCode: 404,
      headers,
      body: JSON.stringify({
        error: 'Not found',
        path
      })
    };
  } catch (error) {
    console.error('Error processing request:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message
      })
    };
  }
}; 