exports.handler = async function(event, context) {
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Content-Type': 'application/json'
  };
  
  // Handle OPTIONS requests (CORS preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }
  
  // Parse the path to determine what to do
  const path = event.path.replace('/.netlify/functions/simpleapi', '');
  
  try {
    // Handle different routes
    if (path === '/health' || path === '') {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          status: 'ok',
          timestamp: new Date().toISOString()
        })
      };
    }
    
    // Auth route
    if (path.startsWith('/auth')) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          route: 'auth',
          message: 'Auth endpoint reached successfully',
          method: event.httpMethod,
          path
        })
      };
    }
    
    // Database route
    if (path.startsWith('/db')) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          route: 'database',
          message: 'Database endpoint reached successfully',
          method: event.httpMethod,
          path
        })
      };
    }
    
    // User route
    if (path.startsWith('/user')) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          route: 'user',
          message: 'User endpoint reached successfully',
          method: event.httpMethod,
          path
        })
      };
    }
    
    // Notion route
    if (path.startsWith('/notion')) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          route: 'notion',
          message: 'Notion endpoint reached successfully',
          method: event.httpMethod,
          path
        })
      };
    }
    
    // Default 404 response
    return {
      statusCode: 404,
      headers,
      body: JSON.stringify({
        error: 'Not found',
        path
      })
    };
  } catch (error) {
    console.error('Error processing request:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message
      })
    };
  }
}; 